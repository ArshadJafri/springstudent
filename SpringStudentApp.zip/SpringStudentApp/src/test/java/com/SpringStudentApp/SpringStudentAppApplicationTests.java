package com.SpringStudentApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStudentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
